package com.example.musicapi.muiscapi;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class HelloApplication extends Application {

    private static final String BASE_URL = "https://theaudiodb.com/api/v1/json/1/";
    private static final String ARTIST_ALBUMS_ENDPOINT = "searchalbum.php?s=";

    // Create UI components
    private BorderPane root;
    private Label titleLabel;
    private Button searchButton;
    private TableView<Album> albumTableView;

    @Override
    public void start(Stage primaryStage) {
        // Initialize UI components
        root = new BorderPane();
        titleLabel = new Label("Music Discovery App");
        searchButton = new Button("Search Albums");
        albumTableView = new TableView<>();

        // Set up event handlers for buttons
        searchButton.setOnAction(e -> searchAlbums());

        // Set up columns for the album TableView
        TableColumn<Album, String> albumNameCol = new TableColumn<>("Album Name");
        albumNameCol.setCellValueFactory(new PropertyValueFactory<>("albumName"));

        TableColumn<Album, String> releaseDateCol = new TableColumn<>("Release Date");
        releaseDateCol.setCellValueFactory(new PropertyValueFactory<>("releaseDate"));

        TableColumn<Album, String> genreCol = new TableColumn<>("Genre");
        genreCol.setCellValueFactory(new PropertyValueFactory<>("genre"));

        // Add columns to the TableView
        albumTableView.getColumns().addAll(albumNameCol, releaseDateCol, genreCol);

        // Create a vertical layout for buttons
        VBox buttonBox = new VBox(10);
        buttonBox.getChildren().addAll(searchButton, albumTableView);

        // Add components to the root pane
        root.setTop(titleLabel);
        root.setCenter(buttonBox);

        // Create the scene
        Scene scene = new Scene(root, 800, 600);

        // Set the stage properties
        primaryStage.setTitle("Music Discovery App");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Method to handle button click and API integration
    private void searchAlbums() {
        String artistName = "coldplay"; // Replace with the desired artist name
        String apiUrl = BASE_URL + ARTIST_ALBUMS_ENDPOINT + artistName;

        try {
            // Make the API request
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            // Read the API response
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // Parse the JSON response using Gson or any JSON parsing library
            // Update the TableView with detailed album information
            List<Album> albums = parseAlbumsFromApiResponse(response.toString());
            albumTableView.getItems().clear();
            albumTableView.getItems().addAll(albums);

        } catch (IOException e) {
            e.printStackTrace();
            // Handle API request or JSON parsing errors
        }
    }

    // Method to parse the JSON response and extract album details
    private List<Album> parseAlbumsFromApiResponse(String json) {
        // Implement JSON parsing here and create a list of Album objects with relevant details
        // For example, you can use Gson to deserialize the JSON response into Album objects.
        return null; // Replace this with the actual list of Album objects
    }

    // Album class to represent album details
    private static class Album {
        private String albumName;
        private String releaseDate;
        private String genre;

        // Constructor, getters, and setters for Album class
        // Implement the constructor, getters, and setters for the Album class.
    }

    public static void main(String[] args) {
        launch(args);
    }
}

