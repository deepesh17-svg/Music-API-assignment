module com.example.musicapi.muiscapi {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.musicapi.muiscapi to javafx.fxml;
    exports com.example.musicapi.muiscapi;
}